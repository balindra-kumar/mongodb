
const express = require("express");
const cors = require("cors"); 

const port = process.env.PORT || 3000;
const app = express();

app.use(cors());


const data =[
    {
    id:1000,
    name: "Chandan Kumar",
    age: 20,
    city: "indore"
    },
    {
    id:1001,
    name: "Monoj Singh",
    age: 25,
    city: "Delhi"
    },
    {
    id:1002,
    name: "Anupam kumar",
    age: 30,
    city: "delhi"
    }
]

app.get('/', async (req, res) => {
    try {
        
        res.json(data);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.get('/single', async (req, res) => {
    try {
        
        res.json({id:'10001', name:'Ritu', age:20, city:'Rohtas'});
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.listen(port,()=>{
    console.log(`Port is listen http://localhost:${port}`);
})